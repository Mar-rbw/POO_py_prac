##Clases
#
#class Auto:
#    marca=""
#    modelo= 0
#    placa=""
#
#taxi=Auto()
#print(taxi.modelo)

#Clase 2

#class persona:
#    doctor= "Victor"
#
#persona.doctor
#print(persona.doctor)

#Hacer el print fuera del class o sale error al llamarlo

#class jugadores_A:
#    j1="Messi"
#    j2="Ronaldo"
#
#class jugadores_B:
#    j3="Marcelo"
#    j1="Falcao"
#    
#print(jugadores_B.j1)

class nombre:
    pass

victor=nombre()
maria=nombre()

#objeto.atributo= valor

victor.edad=30
victor.sexo="Masculino"
victor.pais="bolivia"

maria.edad=25
maria.sexo="femenino"
maria.pais="colombia"

print(victor.edad)
print(victor.pais)
print(maria.edad)